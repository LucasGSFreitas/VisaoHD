//
//  SportsCollectionViewCell.swift
//  MiniChallange2
//
//  Created by guilherme babugia on 24/08/15.
//  Copyright (c) 2015 VisaoHD. All rights reserved.
//

import UIKit

class SportsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var LabelName: UILabel!
}
