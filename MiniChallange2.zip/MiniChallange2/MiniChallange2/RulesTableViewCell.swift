//
//  RulesTableViewCell.swift
//  MiniChallange2
//
//  Created by Lucas Gabriel Silvério de Freitas on 21/08/15.
//  Copyright (c) 2015 VisaoHD. All rights reserved.
//

import UIKit

class RulesTableViewCell: UITableViewCell {

    @IBOutlet weak var labelText: UILabel!
}
