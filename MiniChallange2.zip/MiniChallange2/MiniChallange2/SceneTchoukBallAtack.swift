//
//  SceneTchoukBallAtack.swift
//  MiniChallange2
//
//  Created by Giuliana Salgado on 27/08/15.
//  Copyright (c) 2015 VisaoHD. All rights reserved.
//

import UIKit

class SceneTchoukBallAtack: UIViewController {
    
    
    
}